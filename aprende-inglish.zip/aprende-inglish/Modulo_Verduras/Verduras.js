import React, { Component } from "react";
import { StyleSheet, View, Text, Image, TouchableOpacity } from "react-native";

 class Verduras extends Component {  
   static navigationOptions = {  
       title: 'Verduras',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  

  render(){
 return (
   <View style={styles.container}>
      <Text style={styles.vegetables}>VEGETABLES</Text>
      <View style={styles.rect4}>
        <Image
          source={require("../Imagenes/Verduras/rabano.png")}
          resizeMode="contain"
          style={styles.image7}
        ></Image>
        <Text style={styles.radishRabano1}>Radish / Rábano</Text>
      </View>
      <View style={styles.rect2}>
        <View style={styles.siguienteStack}>
          <Text style={styles.siguiente}>Siguiente</Text>
          <TouchableOpacity style={styles.button}
          onPress={() => this.props.navigation.navigate('Verduras2')}>
            <Text style={styles.siguiente1}>Siguiente</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.rect7}>
        <Image
          source={require("../Imagenes/Verduras/TOMATOO.png")}
          resizeMode="contain"
          style={styles.image6}
        ></Image>
        <Text style={styles.tomatoTomate}>Tomato / Tomate</Text>
      </View>
    </View>
  );
}
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },

  vegetables: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 26,
    marginLeft: 104
  },
  rect4: {
    width: 237,
    height: 189,
    backgroundColor: "#C7DCB6",
    borderRadius: 51,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(171,79,159,1)",
    marginTop: 225,
    marginLeft: 62
  },
  image7: {
    width: 184,
    height: 130,
    marginTop: 13,
    marginLeft: 29
  },
  radishRabano1: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 13,
    marginLeft: 30
  },
  rect2: {
    width: 154,
    height: 49,
    backgroundColor: "rgba(98,220,111,1)",
    borderRadius: 17,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 43,
    marginLeft: 103
  },
  siguiente: {
    top: 12,
    left: 28,
    color: "rgba(0,0,0,1)",
    position: "absolute",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif"
  },
  button: {
    top: 0,
    left: 0,
    width: 154,
    height: 49,
    backgroundColor: "rgba(98,220,111,1)",
    position: "absolute",
    borderRadius: 17,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  siguiente1: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 12,
    marginLeft: 28
  },
  siguienteStack: {
    width: 154,
    height: 49
  },
  rect7: {
    width: 237,
    height: 189,
    backgroundColor: "#C7DCB6",
    borderRadius: 51,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(209,47,45,1)",
    marginTop: -491,
    marginLeft: 62
  },
  image6: {
    width: 110,
    height: 110,
    marginLeft: 70
  },
  tomatoTomate: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 24,
    marginLeft: 30
  }
});

export default Verduras;
