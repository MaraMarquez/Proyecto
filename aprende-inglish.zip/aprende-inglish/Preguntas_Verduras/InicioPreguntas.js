import React, { Component } from "react";
import { StyleSheet, View, Text, Image, TouchableOpacity } from "react-native";

 class PreguntasVerduras extends Component {  
   static navigationOptions = {  
       title: 'Preguntas de verduras',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  

 render() {
  return (
    <View style={styles.container}>
      <View style={styles.holaStackStack}>
        <View style={styles.holaStack}>
          <Text style={styles.hola}>
            ¡Hola!{"\n"}Haz llegado a la sección de preguntas
          </Text>
          <Image
            source={require("../Preguntas_Verduras/Imagenes/zanahoriaa.gif")}
            resizeMode="contain"
            style={styles.image}
          ></Image>
        </View>
        <Text style={styles.loremIpsum}>Presiona siguiente para continuar</Text>
      </View>
      <TouchableOpacity style={styles.button1}
        onPress={() => this.props.navigation.navigate('PreguntasVerduras2')}>
        <Text style={styles.siguiente1}>Siguiente</Text>
      </TouchableOpacity>
    </View>
  );
}
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },

  hola: {
    top: 0,
    color: "#121212",
    position: "absolute",
    fontSize: 22,
    fontFamily: "Roboto, sans-serif",
    textAlign: "center",
    left: 0,
    fontWeight: 'bold'
  },
  image: {
    top: 67,
    left: 12,
    width: 348,
    height: 368,
    position: "absolute"
  },
  holaStack: {
    top: 0,
    left: 0,
    width: 360,
    height: 435,
    position: "absolute"
  },
  loremIpsum: {
    top: 434,
    left: 15,
    color: "#121212",
    position: "absolute",
    fontSize: 18,
    fontFamily: "Roboto, sans-serif",
    textAlign: "center",
    fontWeight: 'bold'
  },
  holaStackStack: {
    width: 360,
    height: 483,
    marginTop: 36
  },
  button1: {
    width: 145,
    height: 47,
    backgroundColor: "rgba(58,78,255,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 27,
    marginLeft: 103
  },
  siguiente1: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 11,
    marginLeft: 25
  }
});

export default PreguntasVerduras;
