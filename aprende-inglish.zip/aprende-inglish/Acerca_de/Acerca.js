import React, { Component } from "react";
import { StyleSheet, View, Text, Button, TextInput, Image } from 'react-native';


  class Acerca extends Component {  
   static navigationOptions = {  
       title: 'Menu de inicio',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  
  render(){
    return (
      <View style={styles.wrapper}>
        <View style={styles.contenido}>
          <Image
            source={require('../Acerca_de/acercaDe.PNG')}
            style={[styles.div, styles.imagen]}
          />

          <Text style={styles.parrafo}>
            {' '}
            El propósito de la aplicación es poder ofrecer una herramienta para
            que las personas que tienen una discapacidad de aprendizaje puedan
            aprender el idioma Inglés{' '}
          </Text>
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignContent: 'center',
    background: '#F3FFC8'
  },
  contenido: {
    flex: 1,
    alignItems: 'center',
    fontSize: 16,
    justifyContent: 'center',
  },
  parrafo: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 300,
    textAlign: 'center',
    marginTop: 15,
    margin: 10,
    fontSize: 18,
    fontFamily: 'Roboto, sans-serif',
  },
  imagen: {
    width: 300,
    height: 160,
  },
});

export default Acerca
