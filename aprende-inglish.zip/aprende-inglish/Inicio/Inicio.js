import React, { Component } from "react";
import { StyleSheet, View, TouchableOpacity, Text, Image } from "react-native";
import Icon from "react-native-vector-icons/EvilIcons";

   class Inicio extends Component {  
   static navigationOptions = {  
       title: 'Aprendé inglés',  
        headerStyle: {  
            backgroundColor: '#58B9AE',  
            
        },  
        headerTintColor: 'black',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  

    render() { 
      return(
   <View style={styles.container}>
      <View style={styles.buttonStack}>
        <TouchableOpacity style={styles.button}
                onPress={() => this.props.navigation.navigate('MenuInicio')}>
            <View style={styles.comencemosStack}>
            <Text style={styles.comencemos}>¡COMENCEMOS!</Text>
            <Icon name="pointer" style={styles.icon}></Icon>
          </View>
         
        </TouchableOpacity>
        <Image
          source={require("../Imagenes/niño2.gif")}
          resizeMode="contain"
          style={styles.image2}
        ></Image>
        <Text style={styles.loremIpsum2}>
          ¡Bienvenido!{"\n"}Aprende inglés con nosotros
        </Text>
      </View>
      <Text style={styles.loremIpsum}>¿No tienes una cuenta?</Text>
      <Text style={styles.registrateAqui}>Registrate aquí</Text>
    </View>
  );
}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1))"
  },
  button: {
    top: 361,
    marginLeft: 55,
    width: 260,
    height: 60,
    backgroundColor: "rgba(88,185,174,1)",
    position: "absolute",    
    borderRadius: 29,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(227,227,239,1)",
    overflow: "scroll"
  },
  comencemos: {
    top: 0,
    left: 0,
    color: "rgba(0,0,0,1)",
    position: "absolute",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif"
  },
  icon: {
    top: 19,
    left: 80,
    position: "absolute",
    color: "rgba(10,10,10,1)",
    fontSize: 40,
    height: 40,
    width: 40
  },
  comencemosStack: {
    width: 200,
    height: 59,
    marginTop: 11,
    marginLeft: 32
  },
  image2: {
    top: 34,
    width: 309,
    height: 341,
    position: "absolute",
    left: 21
  },
  loremIpsum2: {
    top: 0,
    left: 0,
    color: "rgba(5,5,6,1)",
    position: "absolute",
    fontSize: 30,
    fontFamily: "Roboto, sans-serif",
    textAlign: "center"
  },
  buttonStack: {
    width: 356,
    height: 431,
    marginTop: 38,
    marginLeft: 4
  },
  loremIpsum: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 21,
    marginLeft: 53
  },
  registrateAqui: {
    color: "rgba(88,185,174,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 13,
    marginLeft: 95
  }
});

export default Inicio;
