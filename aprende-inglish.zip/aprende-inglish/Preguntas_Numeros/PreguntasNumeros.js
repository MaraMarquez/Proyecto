import React, { Component } from "react";
import { StyleSheet, View, Text, Image, TouchableOpacity } from "react-native";

 class PreguntasNumeros extends Component {  
   static navigationOptions = {  
       title: 'Preguntas de números',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  


 render() {
  return (
    <View style={styles.container}>
      <View style={styles.preguntaStack}>
        <Text style={styles.pregunta}>Pregunta</Text>
        <Image
          source={require("../Preguntas_Numeros/Imagenes/ezgif.com-crop.gif")}
          resizeMode="contain"
          style={styles.image}
        ></Image>
      </View>
      <Image
        source={require("../Preguntas_Numeros/Imagenes/091.gif")}
        resizeMode="contain"
        style={styles.image2}
      ></Image>
      <View style={styles.button2Row}>
        <TouchableOpacity style={styles.button2}>
          <Text style={styles.one}>One</Text>
        </TouchableOpacity>
        <View style={styles.eightStack}>
          <Text style={styles.eight}>Eight</Text>
          <TouchableOpacity style={styles.button4}>
            <Text style={styles.eight2}>Eight</Text>
          </TouchableOpacity>
        </View>
      </View>
      <Text style={styles.queNumeroEs}>¿Qué número es?</Text>
      <View style={styles.buttonRow}>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.nine3}>Nine</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button3}>
          <Text style={styles.five2}>Five</Text>
        </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.button5}
          onPress={() => this.props.navigation.navigate('PreguntasNumeros2')} >
        <Text style={styles.siguiente}>Siguiente</Text>
      </TouchableOpacity>
    </View>
  );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },

  pregunta: {
    top: 26,
    color: "#121212",
    position: "absolute",
    fontSize: 28,
    fontFamily: "roboto-regular",
    textAlign: "center",
    left: 0
  },
  image: {
    top: 0,
    left: 110,
    width: 85,
    height: 67,
    position: "absolute"
  },
  preguntaStack: {
    width: 195,
    height: 67,
    marginLeft: 124
  },
  image2: {
    width: 226,
    height: 219,
    marginTop: 1,
    marginLeft: 67
  },
  button2: {
    width: 152,
    height: 36,
    backgroundColor: "rgba(36,143,223,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(2,78,136,1)",
    shadowOpacity: 0.5
  },
  one: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "helvetica-regular",
    marginTop: 2,
    marginLeft: 54
  },
  eight: {
    top: 4,
    left: 48,
    color: "rgba(255,255,255,1)",
    position: "absolute",
    fontSize: 20,
    fontFamily: "helvetica-regular"
  },
  button4: {
    top: 0,
    left: 0,
    width: 152,
    height: 36,
    backgroundColor: "rgba(222,80,27,1)",
    position: "absolute",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(98,28,2,1)",
    shadowOpacity: 0.5
  },
  eight2: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "helvetica-regular",
    marginTop: 2,
    marginLeft: 48
  },
  eightStack: {
    width: 152,
    height: 36,
    marginLeft: 10
  },
  button2Row: {
    height: 36,
    flexDirection: "row",
    marginTop: 121,
    marginLeft: 23,
    marginRight: 23
  },
  queNumeroEs: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: -138,
    alignSelf: "center"
  },
  button: {
    width: 152,
    height: 36,
    backgroundColor: "rgba(94,198,94,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(3,66,3,1)",
    shadowOpacity: 0.5
  },
  nine3: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "helvetica-regular",
    marginLeft: 50
  },
  button3: {
    width: 152,
    height: 36,
    backgroundColor: "rgba(126,79,179,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(58,5,118,1)",
    shadowOpacity: 0.5,
    marginLeft: 10
  },
  five2: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "helvetica-regular",
    marginLeft: 53
  },
  buttonRow: {
    height: 36,
    flexDirection: "row",
    marginTop: 18,
    marginLeft: 23,
    marginRight: 23
  },
  button5: {
    width: 200,
    height: 36,
    backgroundColor: "rgba(248,231,28,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(3,66,3,1)",
    shadowOpacity: 0.5,
    marginTop: 91,
    marginLeft: 77
  },
  siguiente: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "helvetica-regular",
    marginLeft: 51
  }
});

export default PreguntasNumeros;
