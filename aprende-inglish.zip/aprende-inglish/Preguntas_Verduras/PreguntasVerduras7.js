import React, { Component } from "react";
import { StyleSheet, View, Text, TouchableOpacity, Image } from "react-native";

 class PreguntasVerduras7 extends Component {  
   static navigationOptions = {  
       title: 'Preguntas de verduras',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  

 render() {
  return (
 <View style={styles.container}>
      <Text style={styles.pregunta1}>Pregunta</Text>
      <Text style={styles.loremIpsum1}>
        ¿Cómo se escribe &quot;Alcachofa&quot; en inglés?
      </Text>
      <View style={styles.button1Row}>
        <TouchableOpacity style={styles.button1}>
          <Text style={styles.artichok}>Artichok</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button3}>
          <Text style={styles.artichoke}>Artichoke</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.button2Row}>
        <TouchableOpacity style={styles.button2}>
          <Text style={styles.alcachofa}>Alcachofa</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button4}>
          <Text style={styles.artochoke}>Artochoke</Text>
        </TouchableOpacity>
      </View>
      <Image
        source={require("../Preguntas_Verduras/Imagenes/artichoke.png")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
      <TouchableOpacity style={styles.button5}
      onPress={() => this.props.navigation.navigate('PreguntasVerduras8')}>
        <Text style={styles.siguiente1}>Siguiente</Text>
      </TouchableOpacity>
    </View>
  );
}
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },

  pregunta1: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 37,
    alignSelf: "center"
  },
  loremIpsum1: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    textAlign: "center",
    marginTop: 13
  },
  button1: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(70,115,76,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  artichok: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 10,
    marginLeft: 26
  },
  button3: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(70,115,76,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginLeft: 40
  },
  artichoke: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 10,
    marginLeft: 16
  },
  button1Row: {
    height: 44,
    flexDirection: "row",
    marginTop: 239,
    marginLeft: 24,
    marginRight: 24
  },
  button2: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(70,115,76,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  alcachofa: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 10,
    marginLeft: 16
  },
  button4: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(70,115,76,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginLeft: 40
  },
  artochoke: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 10,
    marginLeft: 16
  },
  button2Row: {
    height: 44,
    flexDirection: "row",
    marginTop: 41,
    marginLeft: 24,
    marginRight: 24
  },
  image: {
    width: 200,
    height: 200,
    marginTop: -339,
    marginLeft: 100
  },
  button5: {
    width: 145,
    height: 47,
    backgroundColor: "rgba(58,78,255,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 160,
    marginLeft: 103
  },
  siguiente1: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 11,
    marginLeft: 25
    }
});

export default PreguntasVerduras7;
