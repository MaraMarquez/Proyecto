import React, { Component } from "react";
import { StyleSheet, View, TouchableOpacity, Text, Image } from "react-native";


   class MenuPreguntas extends Component {  
   static navigationOptions = {  
       title: 'Menu de inicio',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  

   render() { 
  return (
      <View style={styles.container}>
      <View style={styles.buttonStackStack}>
        <View style={styles.buttonStack}>
          <TouchableOpacity style={styles.button}
           onPress={() => this.props.navigation.navigate('PreguntasColores')} >
            <Text style={styles.preguntasDeColores}>Preguntas de colores</Text>
          </TouchableOpacity>
          <Image
            source={require("../Imagenes/poo.gif")}
            resizeMode="contain"
            style={styles.image}
          ></Image>
        </View>
        <Text style={styles.seccionDePreguntas}>Sección de preguntas</Text>
      </View>
      <TouchableOpacity style={styles.button5}
       onPress={() => this.props.navigation.navigate('PreguntasVerduras')} >
        <Text style={styles.loremIpsum1}>Preguntas de verduras</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button4}>
        <Text style={styles.preguntasDeAbc}>Preguntas de abc</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button3}
      onPress={() => this.props.navigation.navigate('PreguntasNumeros')} >
        <Text style={styles.preguntasDeNumeros}>Preguntas de numeros</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button2}
      onPress={() => this.props.navigation.navigate('PreguntasFrutas')} >
        <Text style={styles.preguntasDeFrutas}>Preguntas de frutas</Text>
      </TouchableOpacity>
    </View>
  );
  }
} 
const styles = StyleSheet.create({
    container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  button: {
    top: 119,
    left: 0,
    width: 257,
    height: 51,
    backgroundColor: "rgba(94,198,94,1)",
    position: "absolute",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  preguntasDeColores: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 13,
    marginLeft: 10
  },
  image: {
    top: 0,
    width: 151,
    height: 110,
    position: "absolute",
    left: 51
  },
  buttonStack: {
    top: 18,
    left: 0,
    width: 257,
    height: 170,
    position: "absolute"
  },
  seccionDePreguntas: {
    top: 0,
    color: "#121212",
    position: "absolute",
    fontSize: 25,
    fontFamily: "roboto-condensed-700",
    left: 20
  },
  buttonStackStack: {
    width: 257,
    height: 188,
    marginTop: 17,
    marginLeft: 52
  },
  button5: {
    width: 257,
    height: 51,
    backgroundColor: "rgba(186,222,27,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 45,
    marginLeft: 52
  },
  loremIpsum1: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 13,
    marginLeft: 7
  },
  button4: {
    width: 257,
    height: 51,
    backgroundColor: "rgba(191,146,243,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(34,43,131,1)",
    marginTop: 49,
    marginLeft: 52
  },
  preguntasDeAbc: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 13,
    marginLeft: 7
  },
  button3: {
    width: 257,
    height: 51,
    backgroundColor: "rgba(36,143,223,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(39,78,80,1)",
    marginTop: 41,
    marginLeft: 52
  },
  preguntasDeNumeros: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 13,
    marginLeft: 4
  },
  button2: {
    width: 257,
    height: 51,
    backgroundColor: "rgba(214,98,209,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 41,
    marginLeft: 51
  },
  preguntasDeFrutas: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 14,
    marginLeft: 9
  }
  
});

export default MenuPreguntas;