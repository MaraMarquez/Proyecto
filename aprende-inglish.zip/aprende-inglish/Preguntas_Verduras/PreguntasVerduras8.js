import React, { Component } from "react";
import { StyleSheet, View, Text, TouchableOpacity, Image } from "react-native";

 class PreguntasVerduras8 extends Component {  
   static navigationOptions = {  
       title: 'Preguntas de verduras',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  

 render() {
  return (
     <View style={styles.container}>
      <Text style={styles.pregunta1}>Pregunta</Text>
      <Text style={styles.loremIpsum1}>
        ¿Cómo se escribe &quot;Zanahoria&quot; en inglés?
      </Text>
      <View style={styles.button1Row}>
        <TouchableOpacity style={styles.button1}>
          <Text style={styles.carret}>Carret</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button3}>
          <Text style={styles.carrot}>Carrot</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.button2Row}>
        <TouchableOpacity style={styles.button2}>
          <Text style={styles.cucomber}>Cucomber</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button4}>
          <Text style={styles.cucumber2}>Cucumber</Text>
        </TouchableOpacity>
      </View>
      <Image
        source={require("../Preguntas_Verduras/Imagenes/carrot.gif")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
      <TouchableOpacity style={styles.button5}
      onPress={() => this.props.navigation.navigate('PreguntasVerduras9')}>
        <Text style={styles.siguiente1}>Siguiente</Text>
      </TouchableOpacity>
    </View>
  );
}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  pregunta1: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 37,
    alignSelf: "center"
  },
  loremIpsum1: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    textAlign: "center",
    marginTop: 13
  },
  button1: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(230,107,39,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  carret: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 9,
    marginLeft: 36
  },
  button3: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(230,107,39,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginLeft: 40
  },
  carrot: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 9,
    marginLeft: 32
  },
  button1Row: {
    height: 44,
    flexDirection: "row",
    marginTop: 244,
    marginLeft: 24,
    marginRight: 24
  },
  button2: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(230,107,39,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  cucomber: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 9,
    marginLeft: 10
  },
  button4: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(230,107,39,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginLeft: 40
  },
  cucumber2: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 9,
    marginLeft: 9
  },
  button2Row: {
    height: 44,
    flexDirection: "row",
    marginTop: 41,
    marginLeft: 24,
    marginRight: 24
  },
  image: {
    width: 247,
    height: 243,
    marginTop: -373,
    marginLeft: 65
  },
  button5: {
    width: 145,
    height: 47,
    backgroundColor: "rgba(58,78,255,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 150,
    marginLeft: 103
  },
  siguiente1: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 11,
    marginLeft: 25
  }
});

export default PreguntasVerduras8;
