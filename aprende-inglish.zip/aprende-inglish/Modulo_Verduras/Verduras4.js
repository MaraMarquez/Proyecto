import React, { Component } from "react";
import { StyleSheet, View, Image, Text, TouchableOpacity } from "react-native";


 class Verduras4 extends Component {  
   static navigationOptions = {  
       title: 'Verduras',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    }; 
 render() {
  return (
    <View style={styles.container}>

      <View style={styles.rect1}>
        <Image
          source={require("../Imagenes/Verduras/coliflor2.png")}
          resizeMode="contain"
          style={styles.image4}
        ></Image>
        <Text style={styles.potatoPatata1}>Cauliflower / Coliflor</Text>
      </View>
      <View style={styles.rect2}>
        <View style={styles.siguiente1Stack}>
          <Text style={styles.siguiente1}>Siguiente</Text>
          <TouchableOpacity style={styles.button1}
           onPress={() => this.props.navigation.navigate('MenuInicio')}>
            <Text style={styles.siguiente2}>Siguiente</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.rect3}>
        <Image
          source={require("../Imagenes/Verduras/zanahoria2.png")}
          resizeMode="contain"
          style={styles.image3}
        ></Image>
        <Text style={styles.carrotZanahoria}>Carrot / Zanahoria</Text>
      </View>
      <Text style={styles.vegetables1}>VEGETABLES</Text>
    </View>
  );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },

  rect1: {
    width: 237,
    height: 189,
    backgroundColor: "#C7DCB6",
    borderRadius: 51,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(70,206,70,1)",
    marginTop: 276,
    marginLeft: 62
  },
  image4: {
    width: 137,
    height: 130,
    marginLeft: 50
  },
  potatoPatata1: {
    color: "rgba(0,0,0,1)",
    fontSize: 22,
    fontFamily: "Roboto, sans-serif",
    marginTop: 18,
    marginLeft: 13
  },
  rect2: {
    width: 154,
    height: 49,
    backgroundColor: "rgba(98,220,111,1)",
    borderRadius: 17,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 43,
    marginLeft: 103
  },
  siguiente1: {
    top: 12,
    left: 28,
    color: "rgba(0,0,0,1)",
    position: "absolute",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif"
  },
  button1: {
    top: 0,
    left: 0,
    width: 154,
    height: 49,
    backgroundColor: "rgba(98,220,111,1)",
    position: "absolute",
    borderRadius: 17,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  siguiente2: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 12,
    marginLeft: 28
  },
  siguiente1Stack: {
    width: 154,
    height: 49
  },
  rect3: {
    width: 237,
    height: 189,
    backgroundColor: "#C7DCB6",
    borderRadius: 51,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(68,149,62,1)",
    marginTop: -491,
    marginLeft: 62
  },
  image3: {
    width: 137,
    height: 112,
    marginTop: 22,
    marginLeft: 67
  },
  carrotZanahoria: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginLeft: 13
  },
  vegetables1: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: -229,
    marginLeft: 104
  }
});

export default Verduras4;
