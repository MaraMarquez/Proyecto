
import {
  Text,
  View,
  StyleSheet,
  Image,
  TouchableOpacity,
  Button,
} from 'react-native';
import Constants from 'expo-constants';
import React, { Component } from "react";

 class PreguntasFrutas3 extends Component {  
   static navigationOptions = {  
       title: 'Verduras',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  

  render() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph2}>Pregunta</Text>
      <Image
        resizeMode="contain"
        style={styles.image}
       source={require('../Preguntas_Frutas/Imagenes/3.png')}
      />

      <Text style={styles.paragraph}>
        ¿Cómo se escribe "uva" en Inglés?
      </Text>

      <View style={styles.buttonRow}>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.texto}>Apple</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.texto}>Grape</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.buttonRow}>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.texto}>Watermelon</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.texto}>Orange</Text>
        </TouchableOpacity>
      </View>

        <TouchableOpacity style={styles.buttonSig}
             onPress={() => this.props.navigation.navigate('PreguntasFrutas4')}>
          <Text style={styles.texto2}>Siguiente</Text>
        </TouchableOpacity>

    </View>
  );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#F3FFC8',
    padding: 8,
  },
  paragraph: {
    justifyContent: 'center',
    margin: 10,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: 'Roboto, sans-serif',
    marginTop: 50
  },
  paragraph2: {
    color: '#2B61C6',
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: 'Roboto, sans-serif',
  },
  image: {
    width: 260,
    justifyContent: 'center',
    alignItems: 'center',
    height: 150,
    marginTop: 30,
  },
  buttonRow: {
    height: 36,
    flexDirection: 'row',
    marginTop: 50,
    marginLeft: 23,
    marginRight: 23,
  },
  button: {
    width: 140,
    height: 36,
    backgroundColor: 'rgba(94,198,94,1)',
    borderRadius: 100,
    shadowOffset: {
      width: 5,
      height: 5,
    },
    shadowColor: 'rgba(3,66,3,1)',
    shadowOpacity: 0.5,
    marginLeft: 20,
    marginRight: 20
  },
  texto: {
    color: 'rgba(255,255,255,1)',
    fontSize: 23,
    fontFamily: 'helvetica-regular',
    textAlign:'center'
  },
    texto2: {
    color: 'rgba(255,255,255,1)',
    fontSize: 20,
    fontFamily: 'helvetica-regular',
    textAlign:'center'
  },
    buttonSig: {
    borderRadius: 10,
    width: 100,
    height: 35,
    backgroundColor: '#7E4FB3',
    shadowOffset: {
      width: 5,
      height: 5
    },
    shadowColor: '#222B83',
    elevation: 6,
    alignSelf: 'center',
    marginTop: 100,
  },
});

export default PreguntasFrutas3
