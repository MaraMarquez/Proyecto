import React, { Component } from "react";
import { StyleSheet, View, TouchableOpacity, Text } from "react-native";
import EntypoIcon from "react-native-vector-icons/Entypo";

 class Menu extends Component {  
   static navigationOptions = {  
       title: 'Modulos',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  

   render() { 
      return(
  <View style={styles.container}>
      <Text style={styles.seccionDePreguntas1}>
        ¡Bienvenido al menú de módulos!
      </Text>
      <Text style={styles.loremIpsum}>Selecciona uno para comenzar</Text>
      <TouchableOpacity style={styles.button1}
             onPress={() => this.props.navigation.navigate('InicioColorcitos')}>
        <Text style={styles.colores}>Colores</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button3}
       onPress={() => this.props.navigation.navigate('InicioVerduras')}>
        <Text style={styles.verduras}>Verduras</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button2}>
        <Text style={styles.sabe}>SABE</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button4}
       onPress={() => this.props.navigation.navigate('Numeros')}>
        <Text style={styles.numeros}>Números</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button5}
       onPress={() => this.props.navigation.navigate('Frutas')}>
        <Text style={styles.frutas}>Frutas</Text>
      </TouchableOpacity>
    </View>
  );
      
  }
}
const styles = StyleSheet.create({
container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  seccionDePreguntas1: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-condensed-700",
    textAlign: "center",
    marginTop: 20,
    alignSelf: "center"
  },
  loremIpsum: {
    color: "#2B61C6",
    fontSize: 25,
    fontFamily: "roboto-regular",
    textAlign: "center",
    marginTop: 10,
    marginLeft: 20
  },
  button1: {
    width: 215,
    height: 49,
    backgroundColor: "rgba(94,198,94,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 12,
    marginLeft: 73
  },
  colores: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 12,
    marginLeft: 54
  },
  button3: {
    width: 215,
    height: 49,
    backgroundColor: "rgba(186,222,27,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 47,
    marginLeft: 73
  },
  verduras: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 12,
    marginLeft: 55
  },
  button2: {
    width: 215,
    height: 49,
    backgroundColor: "rgba(175,128,229,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(34,43,131,1)",
    marginTop: 51,
    marginLeft: 73
  },
  sabe: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 12,
    marginLeft: 54
  },
  button4: {
    width: 215,
    height: 49,
    backgroundColor: "rgba(36,143,223,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(39,78,80,1)",
    marginTop: 43,
    marginLeft: 73
  },
  numeros: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 12,
    marginLeft: 54
  },
  button5: {
    width: 215,
    height: 49,
    backgroundColor: "rgba(214,98,209,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 43,
    marginLeft: 72
  },
  frutas: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 12,
    marginLeft: 56
  }
});

export default Menu;



