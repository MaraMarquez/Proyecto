import React, { Component } from "react";
import { StyleSheet, View, Text, TouchableOpacity, Image } from "react-native";

 class PreguntasVerduras2 extends Component {  
   static navigationOptions = {  
       title: 'Preguntas de verduras',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  

 render() {
  return (
 <View style={styles.container}>
      <Text style={styles.pregunta}>Pregunta</Text>
      <View style={styles.loremIpsumStackStack}>
        <View style={styles.loremIpsumStack}>
          <Text style={styles.loremIpsum}>
            ¿Cómo se escribe &quot;Tomate&quot; en inglés?
          </Text>
          <Image
            source={require("../Preguntas_Verduras/Imagenes/tomate.gif")}
            resizeMode="contain"
            style={styles.image}
          ></Image>
        </View>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.tomato}>Tomato</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button2}>
          <Text style={styles.tometo}>Tometo</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.button1Row}>
        <TouchableOpacity style={styles.button1}>
          <Text style={styles.potato}>Potato</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button3}>
          <Text style={styles.patata}>Patata</Text>
        </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.button4}
      
       onPress={() => this.props.navigation.navigate('PreguntasVerduras3')}>
        <Text style={styles.siguiente1}>Siguiente</Text>
      </TouchableOpacity>
    </View>
  );
}
}

const styles = StyleSheet.create({
   container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },

  pregunta: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 36,
    alignSelf: "center"
  },
  loremIpsum: {
    top: 0,
    left: 0,
    color: "#121212",
    position: "absolute",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    textAlign: "center"
  },
  image: {
    top: 47,
    left: 40,
    width: 271,
    height: 241,
    position: "absolute"
  },
  loremIpsumStack: {
    top: 0,
    left: 0,
    width: 360,
    height: 288,
    position: "absolute"
  },
  button: {
    top: 276,
    left: 24,
    width: 136,
    height: 44,
    backgroundColor: "rgba(208,56,56,1)",
    position: "absolute",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  tomato: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 12,
    marginLeft: 25
  },
  button2: {
    top: 276,
    left: 200,
    width: 136,
    height: 44,
    backgroundColor: "rgba(208,56,56,1)",
    position: "absolute",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  tometo: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 12,
    marginLeft: 26
  },
  loremIpsumStackStack: {
    width: 360,
    height: 320,
    marginTop: 14
  },
  button1: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(208,56,56,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  potato: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 9,
    marginLeft: 31
  },
  button3: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(208,56,56,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginLeft: 40
  },
  patata: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 9,
    marginLeft: 32
  },
  button1Row: {
    height: 44,
    flexDirection: "row",
    marginTop: 41,
    marginLeft: 24,
    marginRight: 24
  },
  button4: {
    width: 145,
    height: 47,
    backgroundColor: "rgba(58,78,255,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 25,
    marginLeft: 103
  },
  siguiente1: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 11,
    marginLeft: 25
  }
});

export default PreguntasVerduras2;
