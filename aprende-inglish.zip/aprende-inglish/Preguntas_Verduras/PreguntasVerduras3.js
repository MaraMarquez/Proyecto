import React, { Component } from "react";
import { StyleSheet, View, Text, TouchableOpacity, Image } from "react-native";

 class PreguntasVerduras3 extends Component {  
   static navigationOptions = {  
       title: 'Preguntas de verduras',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  

 render() {
  return (
     <View style={styles.container}>
      <Text style={styles.pregunta1}>Pregunta</Text>
      <Text style={styles.loremIpsum1}>
        ¿Cómo se escribe &quot;Rábano&quot; en inglés?
      </Text>
      <View style={styles.button1Row}>
        <TouchableOpacity style={styles.button1}>
          <Text style={styles.radish}>Radish</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button3}>
          <Text style={styles.rabo}>Rabo</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.button2Row}>
        <TouchableOpacity style={styles.button2}>
          <Text style={styles.rodish}>Ravo</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button4}>
          <Text style={styles.redish}>Redish</Text>
        </TouchableOpacity>
      </View>
      <Image
    source={require("../Preguntas_Verduras/Imagenes/rabanitoo.gif")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
      <TouchableOpacity style={styles.button5}
      onPress={() => this.props.navigation.navigate('PreguntasVerduras4')}>

        <Text style={styles.siguiente1}>Siguiente</Text>
      </TouchableOpacity>
    </View>
  );
}
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },

  pregunta1: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 37,
    alignSelf: "center"
  },
  loremIpsum1: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    textAlign: "center",
    marginTop: 13
  },
  button1: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(240,95,95,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  radish: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 10,
    marginLeft: 26
  },
  button3: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(240,95,95,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginLeft: 36
  },
  rabo: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 10,
    marginLeft: 41
  },
  button1Row: {
    height: 44,
    flexDirection: "row",
    marginTop: 227,
    marginLeft: 28,
    marginRight: 24
  },
  button2: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(240,95,95,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  rodish: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 9,
    marginLeft: 44
  },
  button4: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(240,95,95,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginLeft: 40
  },
  redish: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 9,
    marginLeft: 32
  },
  button2Row: {
    height: 44,
    flexDirection: "row",
    marginTop: 41,
    marginLeft: 24,
    marginRight: 24
  },
  image: {
    width: 214,
    height: 214,
    marginTop: -356,
    marginLeft: 84
  },
  button5: {
    width: 145,
    height: 47,
    backgroundColor: "rgba(58,78,255,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 171,
    marginLeft: 103
  },
  siguiente1: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 11,
    marginLeft: 25
  }
});

export default PreguntasVerduras3;
