import React, { Component } from "react";
import { StyleSheet, View, TouchableOpacity, Text, Image } from "react-native";


   class MenuInicio extends Component {  
   static navigationOptions = {  
       title: 'Menu de inicio',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  

   render() { 
  return (
  <View style={styles.container}>
      <Text style={styles.seccionDePreguntas1}>
        Selecciona una opción para continuar
      </Text>
      <TouchableOpacity style={styles.button1}
         onPress={() => this.props.navigation.navigate('Menu')}>
        <Text style={styles.modulos}>Modulos</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button2}
         onPress={() => this.props.navigation.navigate('MenuPreguntas')}>
        <Text style={styles.preguntas}>Preguntas</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button3}>
        <Text style={styles.usuario}>Usuario</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button4}
         onPress={() => this.props.navigation.navigate('Acerca')}>
        <Text style={styles.informacion}>Información</Text>
      </TouchableOpacity>
      <Image
        source={require("../Imagenes/moradito.gif")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
    </View>
  );
  }
} 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  seccionDePreguntas1: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-condensed-700",
    textAlign: "center",
    marginTop: 34,
    marginLeft: 15
  },
  button1: {
    width: 215,
    height: 49,
    backgroundColor: "rgba(94,198,94,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 157,
    marginLeft: 72
  },
  modulos: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 12,
    marginLeft: 54
  },
  button2: {
    width: 215,
    height: 49,
    backgroundColor: "rgba(186,222,27,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 47,
    marginLeft: 72
  },
  preguntas: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 12,
    marginLeft: 56
  },
  button3: {
    width: 215,
    height: 49,
    backgroundColor: "rgba(175,128,229,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(34,43,131,1)",
    marginTop: 51,
    marginLeft: 72
  },
  usuario: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 12,
    marginLeft: 54
  },
  button4: {
    width: 215,
    height: 49,
    backgroundColor: "rgba(36,143,223,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(39,78,80,1)",
    marginTop: 43,
    marginLeft: 72
  },
  informacion: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 12,
    marginLeft: 54
  },
  image: {
    width: 165,
    height: 137,
    marginTop: -494,
    marginLeft: 111
  }
});

export default MenuInicio;