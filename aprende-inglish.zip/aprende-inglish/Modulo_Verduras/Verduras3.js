import React, { Component } from "react";
import { StyleSheet, View, Text, Image, TouchableOpacity } from "react-native";

 class Verduras3 extends Component {  
   static navigationOptions = {  
       title: 'Verduras',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    }; 

 render() {
  return (
    <View style={styles.container}>

      <Text style={styles.vegetables1}>VEGETABLES</Text>
      <View style={styles.rect1}>
        <Image
          source={require("../Imagenes/Verduras/alcachofa.png")}
          resizeMode="contain"
          style={styles.image4}
        ></Image>
        <Text style={styles.potatoPatata1}>Artichoke / Alcachofa</Text>
      </View>
      <View style={styles.rect2}>
        <View style={styles.siguiente1Stack}>
          <Text style={styles.siguiente1}>Siguiente</Text>
          <TouchableOpacity style={styles.button1}
           onPress={() => this.props.navigation.navigate('Verduras4')}>
            <Text style={styles.siguiente2}>Siguiente</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.rect3}>
        <View style={styles.cabbageColStack}>
          <Text style={styles.cabbageCol}>Cabbage / Col</Text>
          <Image
            source={require("../Imagenes/Verduras/col.png")}
            resizeMode="contain"
            style={styles.image3}
          ></Image>
        </View>
      </View>
    </View>
  );
}
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },

  vegetables1: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 26,
    marginLeft: 104
  },
  rect1: {
    width: 237,
    height: 189,
    backgroundColor: "#C7DCB6",
    borderRadius: 51,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(70,206,70,1)",
    marginTop: 225,
    marginLeft: 62
  },
  image4: {
    width: 140,
    height: 146,
    marginTop: 2,
    marginLeft: 67
  },
  potatoPatata1: {
    color: "rgba(0,0,0,1)",
    fontSize: 22,
    fontFamily: "Roboto, sans-serif",
    marginLeft: 13
  },
  rect2: {
    width: 154,
    height: 49,
    backgroundColor: "rgba(98,220,111,1)",
    borderRadius: 17,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 43,
    marginLeft: 103
  },
  siguiente1: {
    top: 12,
    left: 28,
    color: "rgba(0,0,0,1)",
    position: "absolute",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif"
  },
  button1: {
    top: 0,
    left: 0,
    width: 154,
    height: 49,
    backgroundColor: "rgba(98,220,111,1)",
    position: "absolute",
    borderRadius: 17,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  siguiente2: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 12,
    marginLeft: 28
  },
  siguiente1Stack: {
    width: 154,
    height: 49
  },
  rect3: {
    width: 237,
    height: 189,
    backgroundColor: "#C7DCB6",
    borderRadius: 51,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(68,149,62,1)",
    marginTop: -491,
    marginLeft: 62
  },
  cabbageCol: {
    top: 123,
    left: 0,
    color: "rgba(0,0,0,1)",
    position: "absolute",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif"
  },
  image3: {
    top: 0,
    left: 14,
    width: 154,
    height: 124,
    position: "absolute"
  },
  cabbageColStack: {
    width: 168,
    height: 148,
    marginTop: 11,
    marginLeft: 39
  }
});

export default Verduras3;
