import React, { Component } from "react";
import { StyleSheet, View, Text, Image, TouchableOpacity } from "react-native";

 class Verduras2 extends Component {  
   static navigationOptions = {  
       title: 'Verduras',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  


render() {
  return (
    <View style={styles.container}>
      <Text style={styles.vegetables1}>VEGETABLES</Text>
      <View style={styles.rect1}>
        <Image
          source={require("../Imagenes/Verduras/potato.png")}
          resizeMode="contain"
          style={styles.image3}
        ></Image>
        <Text style={styles.potatoPatata}>Potato / Patata</Text>
      </View>
      <View style={styles.rect2}>
        <View style={styles.siguiente1Stack}>
          <Text style={styles.siguiente1}>Siguiente</Text>
          <TouchableOpacity style={styles.button1}
           onPress={() => this.props.navigation.navigate('Verduras3')}>
            <Text style={styles.siguiente2}>Siguiente</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.rect3}>
        <Image
          source={require("../Imagenes/Verduras/cucumber.png")}
          resizeMode="contain"
          style={styles.image2}
        ></Image>
        <Text style={styles.cucumberPepino}>Cucumber / Pepino</Text>
      </View>
    </View>
  );
  }
 }


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  vegetables1: {
     top: 0,
    left: 0,
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 26,
    marginLeft: 104
  },
  rect1: {
    width: 237,
    height: 189,
    backgroundColor: "#C7DCB6",
    borderRadius: 51,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(148,115,41,1)",
    marginTop: 225,
    marginLeft: 62
  },
  image3: {
    width: 154,
    height: 123,
    marginLeft: 53
  },
  potatoPatata: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 25,
    marginLeft: 30
  },
  rect2: {
    width: 154,
    height: 49,
    backgroundColor: "rgba(98,220,111,1)",
    borderRadius: 17,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 43,
    marginLeft: 103
  },
  siguiente1: {
    top: 12,
    left: 28,
    color: "rgba(0,0,0,1)",
    position: "absolute",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif"
  },
  button1: {
    top: 0,
    left: 0,
    width: 154,
    height: 49,
    backgroundColor: "rgba(98,220,111,1)",
    position: "absolute",
    borderRadius: 17,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  siguiente2: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 12,
    marginLeft: 28
  },
  siguiente1Stack: {
    width: 154,
    height: 49
  },
  rect3: {
    width: 237,
    height: 189,
    backgroundColor: "#C7DCB6",
    borderRadius: 51,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(22,150,13,1)",
    marginTop: -491,
    marginLeft: 62
  },
  image2: {
    width: 165,
    height: 134,
    marginLeft: 42
  },
  cucumberPepino: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginLeft: 10
  }
});

export default Verduras2;
