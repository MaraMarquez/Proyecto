import React, { Component } from "react";
import { StyleSheet, View, Text, TouchableOpacity, Image } from "react-native";
import Icon from "react-native-vector-icons/Entypo";

 class InicioVerduras extends Component {  
   static navigationOptions = {  
       title: 'Verduras',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  
  render() {
  return (
    <View style={styles.container}>
      <Text style={styles.bienvenido}>¡Bienvenido!</Text>
      <Text style={styles.loremIpsum}>
        En esta sección aprenderemos los nombres de las verduras
      </Text>
      <View style={styles.buttonStack}>
        <TouchableOpacity style={styles.button}
         onPress={() => this.props.navigation.navigate('Verduras')}>
          <View style={styles.iniciarStack}>
            <Text style={styles.iniciar}>Iniciar</Text>
            <Icon name="arrow-right" style={styles.icon}></Icon>
          </View>
        </TouchableOpacity>
        <Image
          source={require("../Imagenes/Verduras/source-1.gif")}
          resizeMode="contain"
          style={styles.image}
        ></Image>
      </View>
    </View>
  );
  } 
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  bienvenido: {
    color: "#121212",
    fontSize: 20,
    fontFamily: "Roboto, sans-serif",
    marginTop: 48,
    marginLeft: 111,
    fontWeight: 'bold',
  },
  loremIpsum: {
    color: "rgba(43,97,198,1)",
    fontSize: 20,
    fontFamily: "Roboto, sans-serif",
    textAlign: "center",
    marginTop: 14,
   fontWeight: 'bold',
  },
  button: {
    top: 350,
    left: 75,
    width: 149,
    height: 53,
    backgroundColor: "rgba(126,79,179,1)",
    position: "absolute",
    borderRadius: 18,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(34,43,131,1)"
  },
  iniciar: {
    top: 0,
    left: 0,
    color: "rgba(239,242,247,1)",
    position: "absolute",
    fontSize: 20,
    fontFamily: "Roboto, sans-serif"
  },
  icon: {
    top: 24,
    left: 26,
    position: "absolute",
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    height: 25,
    width: 25
  },
  iniciarStack: {
    width: 67,
    height: 49,
    marginTop: 4,
    marginLeft: 41
  },
  image: {
    top: 0,
    left: 0,
    width: 334,
    height: 354,
    position: "absolute"
  },
  buttonStack: {
    width: 334,
    height: 403,
    marginTop: 29,
    marginLeft: 25
  }
});

export default InicioVerduras;


