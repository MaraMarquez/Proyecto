import React, { Component } from "react";
import { StyleSheet, View, Text, Image, TouchableOpacity } from "react-native";

 class PreguntasNumeros5 extends Component {  
   static navigationOptions = {  
       title: 'Preguntas de números',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  


 render() {
  return (
    <View style={styles.container}>

      <View style={styles.preguntaStack}>
        <Text style={styles.pregunta}>Pregunta</Text>
        <Image
          source={require("../Preguntas_Numeros/Imagenes/ezgif.com-crop.gif")}
          resizeMode="contain"
          style={styles.image}
        ></Image>
      </View>
      <Text style={styles.queNumeroEs}>¿Qué número es?</Text>
      <Image
        source={require("../Preguntas_Numeros/Imagenes/032.gif")}
        resizeMode="contain"
        style={styles.image2}
      ></Image>
      <View style={styles.button5Row}>
        <TouchableOpacity style={styles.button5}>
          <Text style={styles.five1}>Five</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button6}>
          <Text style={styles.seven1}>Seven</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.button7Row}>
        <TouchableOpacity style={styles.button7}>
          <Text style={styles.three1}>Three</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button8}>
          <Text style={styles.one1}>One</Text>
        </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.button9}
       onPress={() => this.props.navigation.navigate('PreguntasNumeros6')} >
        <Text style={styles.siguiente1}>Siguiente</Text>
      </TouchableOpacity>
    </View>
  );
}
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },

  pregunta: {
    top: 26,
    color: "#121212",
    position: "absolute",
    fontSize: 28,
    fontFamily: "roboto-regular",
    textAlign: "center",
    left: 0
  },
  image: {
    top: 0,
    left: 110,
    width: 85,
    height: 67,
    position: "absolute"
  },
  preguntaStack: {
    width: 195,
    height: 67,
    marginLeft: 124
  },
  queNumeroEs: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 239,
    alignSelf: "center"
  },
  image2: {
    width: 155,
    height: 219,
    marginTop: -264,
    marginLeft: 84
  },
  button5: {
    width: 152,
    height: 36,
    backgroundColor: "rgba(94,198,94,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(3,66,3,1)",
    shadowOpacity: 0.5
  },
  five1: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "helvetica-regular",
    marginLeft: 52
  },
  button6: {
    width: 152,
    height: 36,
    backgroundColor: "rgba(126,79,179,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(58,5,118,1)",
    shadowOpacity: 0.5,
    marginLeft: 10
  },
  seven1: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "helvetica-regular",
    marginLeft: 45
  },
  button5Row: {
    height: 36,
    flexDirection: "row",
    marginTop: 63,
    marginLeft: 23,
    marginRight: 23
  },
  button7: {
    width: 152,
    height: 36,
    backgroundColor: "rgba(36,143,223,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(2,78,136,1)",
    shadowOpacity: 0.5
  },
  three1: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "helvetica-regular",
    marginLeft: 43
  },
  button8: {
    width: 152,
    height: 36,
    backgroundColor: "rgba(222,80,27,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(98,28,2,1)",
    shadowOpacity: 0.5,
    marginLeft: 10
  },
  one1: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "helvetica-regular",
    marginLeft: 52
  },
  button7Row: {
    height: 36,
    flexDirection: "row",
    marginTop: 23,
    marginLeft: 23,
    marginRight: 23
  },
  button9: {
    width: 200,
    height: 36,
    backgroundColor: "rgba(248,231,28,1)",
    borderRadius: 100,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(3,66,3,1)",
    shadowOpacity: 0.5,
    marginTop: 32,
    marginLeft: 80
  },
  siguiente1: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "helvetica-regular",
    marginLeft: 48
  }
});

export default PreguntasNumeros5;