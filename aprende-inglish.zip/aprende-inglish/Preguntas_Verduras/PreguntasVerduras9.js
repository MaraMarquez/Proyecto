import React, { Component } from "react";
import { StyleSheet, View, Text, Image, TouchableOpacity } from "react-native";

 class PreguntasVerduras9 extends Component {  
   static navigationOptions = {  
       title: 'Preguntas de verduras',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  

 render() {
  return (
 <View style={styles.container}>
      <Text style={styles.pregunta1}>Pregunta</Text>
      <View style={styles.loremIpsum1StackStack}>
        <View style={styles.loremIpsum1Stack}>
          <Text style={styles.loremIpsum1}>
            ¿Cómo se escribe &quot;Coliflor&quot; en inglés?
          </Text>
          <Image
              source={require("../Preguntas_Verduras/Imagenes/coliflor.png")}
            resizeMode="contain"
            style={styles.image}
          ></Image>
        </View>
        <TouchableOpacity style={styles.button1}>
          <Text style={styles.col}>Col</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button3}>
          <Text style={styles.cauliflow2}>Cauliflow</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.button2Row}>
        <TouchableOpacity style={styles.button2}>
          <Text style={styles.cauliflower}>Cauliflower</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button4}>
          <Text style={styles.coliflower}>Coliflower</Text>
        </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.button5}
      onPress={() => this.props.navigation.navigate('MenuInicio')} > 
        <Text style={styles.siguiente1}>Siguiente</Text>
      </TouchableOpacity>
    </View>
  );
}
}
const styles = StyleSheet.create({
   container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  pregunta1: {
    color: "#121212",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 37,
    alignSelf: "center"
  },
  loremIpsum1: {
    top: 0,
    left: 0,
    color: "#121212",
    position: "absolute",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    textAlign: "center"
  },
  image: {
    top: 37,
    left: 40,
    width: 280,
    height: 272,
    position: "absolute"
  },
  loremIpsum1Stack: {
    top: 0,
    left: 0,
    width: 360,
    height: 309,
    position: "absolute"
  },
  button1: {
    top: 292,
    left: 24,
    width: 136,
    height: 44,
    backgroundColor: "rgba(95,172,69,1)",
    position: "absolute",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  col: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 12,
    marginLeft: 41
  },
  button3: {
    top: 292,
    left: 200,
    width: 136,
    height: 44,
    backgroundColor: "rgba(95,172,69,1)",
    position: "absolute",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  cauliflow2: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 10,
    marginLeft: 17
  },
  loremIpsum1StackStack: {
    width: 360,
    height: 336,
    marginTop: 13
  },
  button2: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(95,172,69,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)"
  },
  cauliflower: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 10,
    marginLeft: 10
  },
  button4: {
    width: 136,
    height: 44,
    backgroundColor: "rgba(95,172,69,1)",
    borderRadius: 16,
    borderColor: "#000000",
    borderWidth: 0,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginLeft: 40
  },
  coliflower: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 10,
    marginLeft: 9
  },
  button2Row: {
    height: 44,
    flexDirection: "row",
    marginTop: 41,
    marginLeft: 24,
    marginRight: 24
  },
  button5: {
    width: 145,
    height: 47,
    backgroundColor: "rgba(58,78,255,1)",
    borderRadius: 15,
    shadowOffset: {
      height: 5,
      width: 5
    },
    shadowColor: "rgba(0,0,0,1)",
    marginTop: 21,
    marginLeft: 103
  },
  siguiente1: {
    color: "rgba(255,255,255,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 11,
    marginLeft: 25
  }
});

export default PreguntasVerduras9;
