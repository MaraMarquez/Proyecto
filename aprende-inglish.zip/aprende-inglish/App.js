
import React from 'react';  
import {createAppContainer} from 'react-navigation'; import {createStackNavigator} from 'react-navigation-stack';  
import Inicio from './Inicio/Inicio';  
import Menu from './Menu_Modulos/Menu';  
import MenuInicio from './Menu_Inicio/MenuInicio'
import InicioColores from './Modulo_Colores/InicioColores'
import InicioVerduras from './Modulo_Verduras/InicioVerduras'
import Acerca from './Acerca_de/Acerca'
import Verduras from './Modulo_Verduras/Verduras'
import Colores from './Modulo_Colores/Colores'
import Colores2 from './Modulo_Colores/Colores2'
import Colores3 from './Modulo_Colores/Colores3'
import InicioColorcitos from './Modulo_Colores/Inicio_Colorcitos'
import Verduras2 from './Modulo_Verduras/Verduras2'
import Verduras3 from './Modulo_Verduras/Verduras3'
import Verduras4 from './Modulo_Verduras/Verduras4'
import Numeros from './Menu_Numeros/Numeros'
import MenuPreguntas from './Menu_Preguntas/Menu_Preguntas'
import Frutas from './Modulo_Frutas/InicioFrutas'
import Frutas1 from './Modulo_Frutas/Frutas'
import Frutas2 from './Modulo_Frutas/Frutas2'
import Frutas3 from './Modulo_Frutas/Frutas3'
import Frutas4 from './Modulo_Frutas/Frutas4'
import PreguntasVerduras from './Preguntas_Verduras/InicioPreguntas'
import PreguntasVerduras2 from './Preguntas_Verduras/PreguntasVerduras2'
import PreguntasVerduras3 from './Preguntas_Verduras/PreguntasVerduras3'
import PreguntasVerduras4 from './Preguntas_Verduras/PreguntasVerduras4'
import PreguntasVerduras5 from './Preguntas_Verduras/PreguntasVerduras5'
import PreguntasVerduras6 from './Preguntas_Verduras/PreguntasVerduras6'
import PreguntasVerduras7 from './Preguntas_Verduras/PreguntasVerduras7'
import PreguntasVerduras8 from './Preguntas_Verduras/PreguntasVerduras8'
import PreguntasVerduras9 from './Preguntas_Verduras/PreguntasVerduras9'
import PreguntasColores from './Preguntas_Colores/PreguntasColores'
import PreguntasColores2 from './Preguntas_Colores/PreguntasColores2'
import PreguntasColores3 from './Preguntas_Colores/PreguntasColores3'
import PreguntasColores4 from './Preguntas_Colores/PreguntasColores4'
import PreguntasColores5 from './Preguntas_Colores/PreguntasColores5'
import PreguntasColores6 from './Preguntas_Colores/PreguntasColores6'
import PreguntasColores7 from './Preguntas_Colores/PreguntasColores7'
import PreguntasColores8 from './Preguntas_Colores/PreguntasColores8'
import PreguntasFrutas from './Preguntas_Frutas/PreguntasFrutas'
import PreguntasFrutas2 from './Preguntas_Frutas/PreguntasFrutas2'
import PreguntasFrutas3 from './Preguntas_Frutas/PreguntasFrutas3'
import PreguntasFrutas4 from './Preguntas_Frutas/PreguntasFrutas4'
import PreguntasFrutas5 from './Preguntas_Frutas/PreguntasFrutas5'
import PreguntasFrutas6 from './Preguntas_Frutas/PreguntasFrutas6'
import PreguntasFrutas7 from './Preguntas_Frutas/PreguntasFrutas7'
import PreguntasNumeros from './Preguntas_Numeros/PreguntasNumeros'
import PreguntasNumeros2 from './Preguntas_Numeros/PreguntasNumeros2'
import PreguntasNumeros3 from './Preguntas_Numeros/PreguntasNumeros3'
import PreguntasNumeros4 from './Preguntas_Numeros/PreguntasNumeros4'
import PreguntasNumeros5 from './Preguntas_Numeros/PreguntasNumeros5'
import PreguntasNumeros6 from './Preguntas_Numeros/PreguntasNumeros6'
import PreguntasNumeros7 from './Preguntas_Numeros/PreguntasNumeros7'
import PreguntasNumeros8 from './Preguntas_Numeros/PreguntasNumeros8'
import PreguntasNumeros9 from './Preguntas_Numeros/PreguntasNumeros9'


const AppNavigator = createStackNavigator( {   
Inicio: Inicio,        
Menu: Menu ,     
MenuInicio: MenuInicio,
InicioColores: InicioColores,
InicioVerduras: InicioVerduras,
Acerca: Acerca,
Verduras: Verduras,
Colores: Colores,
Colores2: Colores2,
Colores3: Colores3,
InicioColorcitos: InicioColorcitos,
Verduras2: Verduras2,
Verduras3: Verduras3,
Verduras4: Verduras4,
Numeros: Numeros,
MenuPreguntas: MenuPreguntas,
Frutas: Frutas,
Frutas1: Frutas1,
Frutas2: Frutas2,
Frutas3: Frutas3,
Frutas4: Frutas4,
PreguntasVerduras: PreguntasVerduras,
PreguntasVerduras2: PreguntasVerduras2,
PreguntasVerduras3: PreguntasVerduras3,
PreguntasVerduras4: PreguntasVerduras4,
PreguntasVerduras5: PreguntasVerduras5,
PreguntasVerduras6: PreguntasVerduras6,
PreguntasVerduras7: PreguntasVerduras7,
PreguntasVerduras8: PreguntasVerduras8,
PreguntasVerduras9: PreguntasVerduras9,
PreguntasColores:PreguntasColores,
PreguntasColores2:PreguntasColores2,
PreguntasColores3:PreguntasColores3,
PreguntasColores4:PreguntasColores4,
PreguntasColores5:PreguntasColores5,
PreguntasColores6:PreguntasColores6,
PreguntasColores7:PreguntasColores7,
PreguntasColores8:PreguntasColores8,
PreguntasFrutas:PreguntasFrutas,
PreguntasFrutas2:PreguntasFrutas2,
PreguntasFrutas3:PreguntasFrutas3,
PreguntasFrutas4:PreguntasFrutas4,
PreguntasFrutas5:PreguntasFrutas5,
PreguntasFrutas6:PreguntasFrutas6,
PreguntasFrutas7:PreguntasFrutas7,
PreguntasNumeros:PreguntasNumeros,
PreguntasNumeros2:PreguntasNumeros2,
PreguntasNumeros3:PreguntasNumeros3,
PreguntasNumeros4:PreguntasNumeros4,
PreguntasNumeros5:PreguntasNumeros5,
PreguntasNumeros6:PreguntasNumeros6,
PreguntasNumeros7:PreguntasNumeros7,
PreguntasNumeros8:PreguntasNumeros8,
PreguntasNumeros9:PreguntasNumeros9
}, 

{       initialRouteName: "Inicio"      }  );  
export default createAppContainer(AppNavigator); 

