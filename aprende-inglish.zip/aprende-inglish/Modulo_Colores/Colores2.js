import React, { Component } from "react";
import { Text, View, StyleSheet, Image, TouchableOpacity, Button } from 'react-native';
import Constants from 'expo-constants';


 class Colores2 extends Component {  
   static navigationOptions = {  
       title: 'Colores',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    };  
 render() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph2}>
        COLORES
      </Text>
      <Image
        resizeMode="contain"
        style={styles.image}
        source={require("../Imagenes/Colores/5.PNG")}
      />
      <Image
        resizeMode="contain"
        style={styles.image2}
        source={require("../Imagenes/Colores/6.PNG")}
      />
      <TouchableOpacity
        style={styles.buttonSiguiente}
        title="Siguiente"
       onPress={() => this.props.navigation.navigate('Colores3')} > 
        <Text style={styles.text}>Siguiente</Text>
      </TouchableOpacity>
    </View>
  );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#F3FFC8',
    padding: 8,
  },
  paragraph2: {
    color: '#2B61C6',
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: 'Roboto, sans-serif',
  },
  text: {
    color: 'white',
    textAlign: 'center',
    fontFamily: 'Roboto, sans-serif',
    fontSize: 20,
    marginTop: 3,
  },
  image: {
    width: 400,
    justifyContent: 'center',
    alignItems: 'center',
    height: 200,
    marginTop: 30,
  },
   image2: {
    width: 400,
    justifyContent: 'center',
    alignItems: 'center',
    height: 200,
    marginTop: 40,
  },
  buttonSiguiente: {
    borderRadius: 10,
    width: 100,
    height: 35,
    backgroundColor: '#7E4FB3',
    shadowOffset: {
      width: 5,
      height: 5
    },
    shadowColor: '#222B83',
    elevation: 6,
    alignSelf: 'center',
    marginTop: 40,
  },
});

export default Colores2;
