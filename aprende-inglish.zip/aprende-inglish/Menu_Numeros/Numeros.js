import React, { Component } from "react";
import { StyleSheet, View, Text, Image, ImageBackground } from "react-native";

 class Numeros extends Component {  
   static navigationOptions = {  
       title: 'Numeros',  
        headerStyle: {  
            backgroundColor: '#3F51B5',  
            
        },  
        headerTintColor: 'white',  
        headerTitleStyle: {  
            fontWeight: 'bold',
          
        },  
    }; 

render() {
  return (
    <View style={styles.container}>
      <Text style={styles.numbers}>Numbers</Text>
      <View style={styles.imageRow}>
        <Image
          source={require("../Imagenes/Numeros/011.gif")}
          resizeMode="contain"
          style={styles.image}
        ></Image>
        <View style={styles.image2Stack}>
          <Image
            source={require("../Imagenes/Numeros/02.gif")}
            resizeMode="contain"
            style={styles.image2}
          ></Image>
          <Image
            source={require("../Imagenes/Numeros/03.gif")}
            resizeMode="contain"
            style={styles.image3}
          ></Image>
        </View>
      </View>
      <View style={styles.oneRow}>
        <Text style={styles.one}>One</Text>
        <Text style={styles.two}>Two</Text>
        <Text style={styles.three}>Three</Text>
      </View>
      <View style={styles.image4ColumnRow}>
        <View style={styles.image4Column}>
          <Image
            source={require("../Imagenes/Numeros/04.gif")}
            resizeMode="contain"
            style={styles.image4}
          ></Image>
          <Text style={styles.four}>Four</Text>
        </View>
        <View style={styles.image5Column}>
          <Image
            source={require("../Imagenes/Numeros/05.gif")}
            resizeMode="contain"
            style={styles.image5}
          ></Image>
          <Text style={styles.five}>Five</Text>
        </View>
        <ImageBackground
          source={require("../Imagenes/Numeros/061.gif")}
          resizeMode="contain"
          style={styles.image6}
          imageStyle={styles.image6_imageStyle}
        >
          <Text style={styles.six}>Six</Text>
        </ImageBackground>
      </View>
      <View style={styles.image7StackStackRow}>
        <View style={styles.image7StackStack}>
          <View style={styles.image7Stack}>
            <Image
              source={require("../Imagenes/Numeros/07.gif")}
              resizeMode="contain"
              style={styles.image7}
            ></Image>
            <Image
              source={require("../Imagenes/Numeros/081.gif")}
              resizeMode="contain"
              style={styles.image8}
            ></Image>
            <Text style={styles.eight}>Eight</Text>
          </View>
          <Text style={styles.seven}>Seven</Text>
        </View>
        <View style={styles.image9Stack}>
          <Image
            source={require("../Imagenes/Numeros/09.gif")}
            resizeMode="contain"
            style={styles.image9}
          ></Image>
          <Text style={styles.nine}>Nine</Text>
        </View>
      </View>
    </View>
  );
}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(243,255,200,1)"
  },
  numbers: {
    color: "rgba(43,97,198,1)",
    fontSize: 25,
    fontFamily: "Roboto, sans-serif",
    marginTop: 70,
    marginLeft: 132
  },
  image: {
    width: 111,
    height: 117
  },
  image2: {
    top: 0,
    left: 0,
    width: 111,
    height: 117,
    position: "absolute"
  },
  image3: {
    top: 23,
    left: 110,
    width: 108,
    height: 86,
    position: "absolute"
  },
  image2Stack: {
    width: 218,
    height: 107
  },
  imageRow: {
    height: 107,
    flexDirection: "row",
    marginTop: 52,
    marginRight: 31
  },
  one: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    

  },
  two: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginLeft: 59
  },
  three: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginLeft: 61
  },
  oneRow: {
    height: 25,
    flexDirection: "row",
    marginLeft: 48,
    marginRight: 38
  },
  image4: {
    width: 92,
    height: 106
  },
  four: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginLeft: 18,
    marginTop: 1
    
  },
  image4Column: {
    width: 92,
    marginTop: 27
  },
  image5: {
    width: 111,
    height: 133
  },
  five: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginLeft: 30,
    marginTop: 1
  },
  image5Column: {
    width: 111,
    marginLeft: 1
  },
  image6: {
    width: 108,
    height: 146,
    marginLeft: 12,
    marginTop: 13
  },
  image6_imageStyle: {},
  six: {
    color: "rgba(0,0,0,1)",
    fontSize: 25,
    fontFamily: "roboto-regular",
    marginTop: 121,
    marginLeft: 29
  },
  image4ColumnRow: {
    height: 159,
    flexDirection: "row",
       marginTop: 14, 
    marginLeft: 21,
    marginRight: 15
  },
  image7: {
    top: 13,
    left: 0,
    width: 97,
    height: 133,
    position: "absolute"
  },
  image8: {
    top: 0,
    left: 91,
    width: 109,
    height: 165,
    position: "absolute"
  },
  eight: {
    top: 141,
    left: 117,
    color: "rgba(0,0,0,1)",
    position: "absolute",
    fontSize: 25,
    fontFamily: "roboto-regular"
  },
  image7Stack: {
    top: 0,
    left: 0,
    width: 200,
    height: 165,
    position: "absolute"
  },
  seven: {
    top: 140,
    left: 10,
    color: "rgba(0,0,0,1)",
    position: "absolute",
    fontSize: 25,
    fontFamily: "roboto-regular"
  },
  image7StackStack: {
    width: 199,
    height: 166
  },
  image9: {
    top: 0,
    left: 0,
    width: 108,
    height: 146,
    position: "absolute"
  },
  nine: {
    top: 133,
    left: 26,
    color: "rgba(0,0,0,1)",
    position: "absolute",
    fontSize: 25,
    fontFamily: "roboto-regular"
  },
  image9Stack: {
    width: 108,
    height: 159,
    marginLeft: 8,
    marginTop: 7
  },
  image7StackStackRow: {
    height: 165,
    flexDirection: "row",
    marginTop: 12,
    marginLeft: 29,
    marginRight: 15
  }
});

export default Numeros;
